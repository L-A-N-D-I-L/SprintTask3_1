package croupG119.sprintTask.sprintTask3_1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprintTask31Application {

	public static void main(String[] args) {
		SpringApplication.run(SprintTask31Application.class, args);
	}

}
