package croupG119.sprintTask.sprintTask3_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SprintTask31ApplicationTests {

	@Test
	void contextLoads() {
	}

}
